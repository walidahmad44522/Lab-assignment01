#include <iostream>
#include <cmath>
using namespace std;

bool isArmstrong(int num) {
    int original = num, digits = 0, sum = 0;

    for (int t = num; t > 0; t /= 10)
        digits++;

    while (num > 0) {
        int d = num % 10;
        sum += pow(d, digits);
        num /= 10;
    }
    return sum == original;
}

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;

    if (isArmstrong(n))
        cout << n << " is an Armstrong number." << endl;
    else
        cout << n << " is not an Armstrong number." << endl;
    return 0;
}
