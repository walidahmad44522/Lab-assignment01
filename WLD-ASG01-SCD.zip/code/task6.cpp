#include <iostream>
using namespace std;

int linearSearch(int arr[], int size, int key) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == key)
            return i;
    }
    return -1;
}

int main() {
    int arr[] = {12, 45, 7, 23, 56, 89, 34, 61, 5, 90};
    int size = sizeof(arr) / sizeof(arr[0]);
    int key;

    cout << "Array: ";
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;

    cout << "Enter value to search: ";
    cin >> key;

    int index = linearSearch(arr, size, key);
    if (index != -1)
        cout << key << " found at index " << index << " (position " << index + 1 << ")." << endl;
    else
        cout << key << " not found in the array." << endl;
    return 0;
}
