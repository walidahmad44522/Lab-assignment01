#include <iostream>
using namespace std;

int main() {
    string name = "Tariq Khan";
    string regNo = "26101";
    string course = "Software Construction and Development";

    cout << "Name               : " << name << endl;
    cout << "Registration Number: " << regNo << endl;
    cout << "Course Name        : " << course << endl;
    return 0;
}
